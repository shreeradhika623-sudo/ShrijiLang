#ifndef VALUE_H
#define VALUE_H

#include <string.h>
#include <stdlib.h>

#include "ast.h"

/*──────────────────────────────────────────────
  VALUE TYPES
──────────────────────────────────────────────*/
typedef enum {
    VAL_NULL = 0,
    VAL_NUMBER,
    VAL_STRING,
    VAL_FUNCTION   /* ✅ new */
} ValueType;

typedef struct {
    ValueType type;
    long long number;
    char *string;

    /* ✅ function value */
    ASTNode *function;
} Value;

/* constructors */
static inline Value value_null(void)
{
    Value v;
    v.type = VAL_NULL;
    v.number = 0;
    v.string = NULL;
    v.function = NULL;
    return v;
}

static inline Value value_number(long long n)
{
    Value v;
    v.type = VAL_NUMBER;
    v.number = n;
    v.string = NULL;
    v.function = NULL;
    return v;
}

static inline Value value_string(const char *s)
{
    Value v;
    v.type = VAL_STRING;
    v.number = 0;
    v.function = NULL;

    if (!s) {
        v.string = NULL;
        return v;
    }

    v.string = (char *)malloc(strlen(s) + 1);
    if (!v.string) return value_null();

    strcpy(v.string, s);
    return v;
}

/* ✅ function constructor */
static inline Value value_function(ASTNode *fn)
{
    Value v;
    v.type = VAL_FUNCTION;
    v.number = 0;
    v.string = NULL;
    v.function = fn;
    return v;
}

/* copy + free */
static inline Value value_copy(Value src)
{
    if (src.type == VAL_STRING) {
        return value_string(src.string ? src.string : "");
    }
    if (src.type == VAL_NUMBER) {
        return value_number(src.number);
    }
    if (src.type == VAL_FUNCTION) {
        /* function node pointer copy (AST is owned elsewhere) */
        return value_function(src.function);
    }
    return value_null();
}

static inline void value_free(Value *v)
{
    if (!v) return;

    if (v->type == VAL_STRING && v->string) {
        free(v->string);
        v->string = NULL;
    }

    /* function is not freed here */
    v->function = NULL;

    v->type = VAL_NULL;
    v->number = 0;
}

#endif
