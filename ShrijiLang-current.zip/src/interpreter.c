#include <stdio.h>
#include <string.h>

#include "../include/interpreter.h"
#include "../include/ast.h"
#include "../include/env.h"
#include "../include/error.h"
#include "../include/state.h"
#include "../include/event.h"
#include "../include/command.h"
#include "../include/value.h"

#include "../shiri/shiri.h"

/*──────────────────────────────────────────────────────────────
 | SHRIJI TRUTH DIARY — SINGLE SOURCE OF FACT
 *──────────────────────────────────────────────────────────────*/
ShrijiTruthDiary SHRIJI_DIARY = {0};

/*──────────────────────────────────────────────────────────────
 | GLOBAL EXECUTION STATE
 *──────────────────────────────────────────────────────────────*/
ExecutionState SHRIJI_STATE;

/* Loop control flags */
static int BREAK_FLAG = 0;
static int CONTINUE_FLAG = 0;

/* Return control flags */
static int RETURN_FLAG = 0;
static Value RETURN_VALUE;

/*──────────────────────────────────────────────────────────────
 | STATE DECISION HOOK
 *──────────────────────────────────────────────────────────────*/
static int state_allows_execution(void)
{
    if (SHRIJI_STATE.safety == STATE_CRITICAL) {
        const char *out = shiri_process("system:halted");
        if (out && *out)
            printf("%s\n", out);
        return 0;
    }
    return 1;
}

/*──────────────────────────────────────────────────────────────
 | SAFE DIVISION
 *──────────────────────────────────────────────────────────────*/
static long long safe_div(long long a, long long b)
{
    if (b == 0) {
        event_fire(EVENT_ERROR, "division by zero");
        shriji_error(
            E_PARSE_02,
            "division",
            "division by zero",
            "denominator must not be zero"
        );
        return 0;
    }
    return a / b;
}

/*──────────────────────────────────────────────────────────────
 | SAFE MODULO
 *──────────────────────────────────────────────────────────────*/
static long long safe_mod(long long a, long long b)
{
    if (b == 0) {
        event_fire(EVENT_ERROR, "modulo by zero");
        shriji_error(
            E_PARSE_02,
            "modulo",
            "modulo by zero",
            "denominator must not be zero"
        );
        return 0;
    }
    return a % b;
}

/*──────────────────────────────────────────────────────────────
 | Value → number helper
 *──────────────────────────────────────────────────────────────*/
static long long value_to_number(Value v)
{
    if (v.type == VAL_NUMBER)
        return v.number;
    return 0;
}

/*──────────────────────────────────────────────────────────────
 | MAIN EVALUATOR
 *──────────────────────────────────────────────────────────────*/
Value eval(ASTNode *node, Env *env)
{
    static int state_initialized = 0;

    if (!state_initialized) {
        state_init(&SHRIJI_STATE);
        state_initialized = 1;
    }

    if (!state_allows_execution() || !node)
        return value_null();

    /* 🧠 GLOBAL STEP COUNTER */
    if (node->type != AST_WHILE &&
        node->type != AST_BREAK &&
        node->type != AST_CONTINUE &&
        node->type != AST_BLOCK &&
        node->type != AST_PROGRAM) {
        SHRIJI_STATE.steps_used++;
    }

    if (SHRIJI_STATE.steps_used > SHRIJI_STATE.max_steps) {
        shriji_error(
            E_PARSE_02,
            "runtime",
            "execution limit exceeded",
            "possible infinite loop detected"
        );
        SHRIJI_STATE.safety = STATE_CRITICAL;
        return value_null();
    }



switch (node->type) {

    case AST_BREAK:
        BREAK_FLAG = 1;
        return value_null();

    case AST_CONTINUE:
        CONTINUE_FLAG = 1;
        return value_null();

case AST_RETURN: {
        Value v = value_null();
        if (node->return_expr)
            v = eval(node->return_expr, env);

        RETURN_FLAG = 1;
        RETURN_VALUE = v;
        return v;
    }
    /*──────────────────────────────────────────────
      FUNCTIONS
    ──────────────────────────────────────────────*/


    case AST_FUNCTION: {
        /* store function AST node into env */
        env_set(env, node->function_name, value_function(node));
        return value_null();
    }



case AST_CALL: {
    /* find function */
    if (!env_exists(env, node->function_name)) {
        shriji_error(
            E_PARSE_02,
            node->function_name,
            "function not found",
            "define using: kaam name(...) { ... }"
        );
        return value_null();
    }

    Value fnv = env_get(env, node->function_name);
    if (fnv.type != VAL_FUNCTION || !fnv.function) {
        shriji_error(
            E_PARSE_02,
            node->function_name,
            "not a function",
            "name must refer to a function"
        );
        return value_null();
    }

    ASTNode *fn = fnv.function;

    /* validate arg count */
    if (fn->param_count != node->arg_count) {
        shriji_error(
            E_PARSE_02,
            node->function_name,
            "argument count mismatch",
            "call with correct number of args"
        );
        return value_null();
    }

    /* save outer return state (nested calls safe) */
    int old_return_flag = RETURN_FLAG;
    Value old_return_value = RETURN_VALUE;

    RETURN_FLAG = 0;
    RETURN_VALUE = value_null();

    /* new call scope */
    env_push_scope(env);

    /* bind params */
    for (int i = 0; i < fn->param_count; i++) {
        ASTNode *p = fn->params[i];
        Value av = eval(node->args[i], env);
        env_set(env, p->name, av);
    }

    /* run body */
    Value result = eval(fn->body, env);

    if (RETURN_FLAG)
        result = RETURN_VALUE;

    /* end call scope */
    env_pop_scope(env);

    /* restore outer return state */
    RETURN_FLAG = old_return_flag;
    RETURN_VALUE = old_return_value;

    return result;
}



    /*──────────────────────────────────────────────
      CORE VALUES
    ──────────────────────────────────────────────*/
    case AST_NUMBER:
        return value_number(node->number_value);

    case AST_STRING:
        return value_string(node->string_value);

    case AST_IDENTIFIER: {

        if (!env_exists(env, node->name)) {
            char event[64];
            snprintf(event, sizeof(event), "shunya:%.*s", 48, node->name);

            const char *out = shiri_process(event);
            if (out && *out)
                printf("%s\n", out);

            return value_null();
        }

        return env_get(env, node->name);
    }

    case AST_ASSIGNMENT: {
        Value value = eval(node->value, env);
        env_set(env, node->name, value);

        event_fire(EVENT_ASSIGNMENT, node->name);
        state_on_success(&SHRIJI_STATE);

        return value;
    }

    case AST_UPDATE: {
        if (!env_exists(env, node->name)) {
            shriji_error(
                E_ASSIGN_01,
                node->name,
                "variable not declared",
                "use mavi x = ... first"
            );
            return value_null();
        }

        Value value = eval(node->value, env);
        env_update(env, node->name, value);

        event_fire(EVENT_ASSIGNMENT, node->name);
        state_on_success(&SHRIJI_STATE);

        return value;
    }


case AST_BINARY: {
        Value Lv = eval(node->left, env);
        Value Rv = eval(node->right, env);


        char op = node->op[0];

        /* ───────── STRING SUPPORT ───────── */


    /* string concatenation: "a" + "b" OR "x=" + 10 */
    if (op == '+' && (Lv.type == VAL_STRING || Rv.type == VAL_STRING)) {

        const char *Ls = (Lv.type == VAL_STRING && Lv.string) ? Lv.string : NULL;
        const char *Rs = (Rv.type == VAL_STRING && Rv.string) ? Rv.string : NULL;

        char Lbuf[64];
        char Rbuf[64];

        if (!Ls) {
            if (Lv.type == VAL_NUMBER) {
                snprintf(Lbuf, sizeof(Lbuf), "%lld", Lv.number);
                Ls = Lbuf;
            } else {
                Ls = "";
            }
        }

        if (!Rs) {
            if (Rv.type == VAL_NUMBER) {
                snprintf(Rbuf, sizeof(Rbuf), "%lld", Rv.number);
                Rs = Rbuf;
            } else {
                Rs = "";
            }
        }

        size_t len = strlen(Ls) + strlen(Rs);
        char *out = (char *)malloc(len + 1);
        if (!out) return value_null();

        strcpy(out, Ls);
        strcat(out, Rs);

        Value v;
        v.type = VAL_STRING;
        v.number = 0;
        v.string = out;
        return v;
    }

    /* string compare */
    if ((op == '=' || op == '!') && (Lv.type == VAL_STRING || Rv.type == VAL_STRING)) {

        const char *Ls = (Lv.type == VAL_STRING && Lv.string) ? Lv.string : "";
        const char *Rs = (Rv.type == VAL_STRING && Rv.string) ? Rv.string : "";

        int eq = (strcmp(Ls, Rs) == 0);

        if (op == '=') return value_number(eq);
        if (op == '!') return value_number(!eq);
    }

    /* ───────── NUMBER SUPPORT (existing) ───────── */

    long long L = value_to_number(Lv);
    long long R = value_to_number(Rv);

    if (op == '+') return value_number(L + R);
    if (op == '-') return value_number(L - R);
    if (op == '*') return value_number(L * R);
    if (op == '/') return value_number(safe_div(L, R));
    if (op == '%') return value_number(safe_mod(L, R));

    if (op == '>') return value_number(L > R);
    if (op == '<') return value_number(L < R);
    if (op == '=') return value_number(L == R);
    if (op == '!') return value_number(L != R);

    return value_null();
}


    case AST_NOT: {
        Value v = eval(node->left, env);
        return value_number(!value_to_number(v));
    }

    case AST_IF: {
        Value condv = eval(node->condition, env);
        long long cond = value_to_number(condv);

        if (cond)
            return eval(node->left, env);
        else if (node->else_block)
            return eval(node->else_block, env);

        return value_null();
    }

    case AST_WHILE: {
        Value last = value_null();
        int local_guard = 0;

        while (value_to_number(eval(node->condition, env))) {

            CONTINUE_FLAG = 0;

            last = eval(node->body, env);

            /* ✅ return must exit loop immediately */
            if (RETURN_FLAG)
                return RETURN_VALUE;

            if (CONTINUE_FLAG) {
                CONTINUE_FLAG = 0;
                continue;
            }

            if (BREAK_FLAG) {
                BREAK_FLAG = 0;
                break;
            }

            if (++local_guard > 1000000) {
                shriji_error(
                    E_PARSE_02,
                    "loop",
                    "infinite loop detected",
                    "use rukja or fix condition"
                );
                SHRIJI_STATE.safety = STATE_CRITICAL;
                break;
            }
        }

        return last;
    }


case AST_BLOCK: {
    Value last = value_null();

    /* ✅ new scope for { } */
    env_push_scope(env);

    for (int i = 0; i < node->stmt_count; i++) {

        last = eval(node->statements[i], env);

        if (RETURN_FLAG || BREAK_FLAG || CONTINUE_FLAG)
            break;
    }

    /* ✅ scope ends */
    env_pop_scope(env);

    if (RETURN_FLAG)
        return RETURN_VALUE;

    return last;
}

case AST_PROGRAM: {
    Value last = value_null();

    for (int i = 0; i < node->stmt_count; i++) {

        last = eval(node->statements[i], env);

        if (RETURN_FLAG || BREAK_FLAG || CONTINUE_FLAG)
            break;
    }

    if (RETURN_FLAG)
        return RETURN_VALUE;

    return last;
}

    case AST_COMMAND: {

        CommandType cmd = resolve_command(node->command_name);

        if (cmd == CMD_UNKNOWN) {
            shriji_error(
                E_PARSE_02,
                "command",
                "unknown command",
                "command not recognized"
            );
            return value_null();
        }

        /* ✅ BOLO print handling */
        if (cmd == CMD_BOLO) {

            Value v = value_null();
            if (node->value)
                v = eval(node->value, env);

            if (v.type == VAL_STRING) {
                printf("%s\n", v.string ? v.string : "");
            } else if (v.type == VAL_NUMBER) {
                printf("%lld\n", v.number);
            } else {
                printf("0\n");
            }

            return value_null();
        }

        /* other commands */
        int status = execute_command(cmd);
        return value_number(status);
    }

    default:
        return value_null();
    }
}

/*──────────────────────────────────────────────────────────────
 | PROGRAM RUNNER
 *──────────────────────────────────────────────────────────────*/
Value run_program(ASTNode *program, Env *env)
{
    /* reset flags every run */
    BREAK_FLAG = 0;
    CONTINUE_FLAG = 0;
    RETURN_FLAG = 0;
    RETURN_VALUE = value_null();

    if (!program || program->type != AST_PROGRAM)
        return value_null();

    return eval(program, env);
}
