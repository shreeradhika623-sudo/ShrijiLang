#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/parser.h"
#include "../include/token.h"
#include "../include/ast.h"
#include "../include/error.h"

/*──────────────────────────────────────────────
 | SHRIJILANG PARSER — V1 STABLE
 | Supports:
 |   - mavi (declaration)
 |   - update (x = expr)
 |   - if/else (agar/warna)
 |   - while (jabtak)
 |   - break/continue (rukja/chalu)
 |   - return (wapas)
 |   - functions (kaam)
 |   - function call: add(10, 20)
 |   - newline aware
 *──────────────────────────────────────────────*/

static ASTNode *parse_statement(void);
static ASTNode *parse_block(void);
static ASTNode *parse_if(void);
static ASTNode *parse_while(void);
static ASTNode *parse_return(void);
static ASTNode *parse_function(void);

static ASTNode *parse_assignment(void);
static ASTNode *parse_update_or_identifier(void);

static ASTNode *parse_comparison(void);
static ASTNode *parse_expression(void);
static ASTNode *parse_term(void);
static ASTNode *parse_unary(void);
static ASTNode *parse_primary(void);

static Token current;

/*──────────────────────────────────────────────
 | HELPER BLOCK
 *──────────────────────────────────────────────*/
static void advance(void)
{
    current = scan_token();
}

static int expect(TokenType t, ShrijiErrorCode c,
                  const char *ctx, const char *msg, const char *hint)
{
    if (current.type == t) {
        advance();
        return 1;
    }

    /* show line/col */
    shriji_error_at(current, c, ctx, msg, hint);
    return 0;
}

static void skip_separators(void)
{
    while (current.type == TOKEN_NEWLINE) {
        advance();
    }
}

/*──────────────────────────────────────────────
 | PROGRAM BLOCK
 *──────────────────────────────────────────────*/
ASTNode *parse_program(const char *source)
{
    init_tokenizer(source);
    advance();

    ASTNode **stmts = NULL;
    int count = 0;

    while (current.type != TOKEN_EOF) {

        skip_separators();
        if (current.type == TOKEN_EOF)
            break;

        ASTNode *s = parse_statement();
        if (!s) return NULL;

        stmts = realloc(stmts, sizeof(ASTNode*) * (count + 1));
        stmts[count++] = s;

        skip_separators();
    }

    return new_program_node(stmts, count);
}

/*──────────────────────────────────────────────
 | STATEMENT SWITCH BLOCK ✅
 *──────────────────────────────────────────────*/

static ASTNode *parse_statement(void)
{
    skip_separators();

    if (current.type == TOKEN_LEFT_BRACE) return parse_block();
    if (current.type == TOKEN_AGAR)       return parse_if();
    if (current.type == TOKEN_JABTAK)     return parse_while();
    if (current.type == TOKEN_WAPAS)      return parse_return();

    /* ✅ samay */
    if (current.type == TOKEN_SAMAY) {
        advance();          /* consume 'samay' */
        skip_separators();
        return new_command_node("samay", NULL);
    }

    if (current.type == TOKEN_KAAM)       return parse_function();
    if (current.type == TOKEN_MAVI)       return parse_assignment();

    /* rukja */
    if (current.type == TOKEN_RUKJA) {
        advance();
        skip_separators();
        return new_break_node();
    }

    /* chalu */
    if (current.type == TOKEN_CHALU) {
        advance();
        skip_separators();
        return new_continue_node();
    }

    /* bolo <expr> */
    if (current.type == TOKEN_BOLO) {

        advance(); /* consume 'bolo' */
        skip_separators();

        /* ✅ must allow full expression (a+b, calls, etc.) */
        ASTNode *arg = parse_expression();
        if (!arg) return NULL;

        skip_separators();
        return new_command_node("bolo", arg);
    }

    /* Identifier: update OR call OR identifier expr */
    if (current.type == TOKEN_IDENTIFIER) {
        return parse_update_or_identifier();
    }

    /* allow raw expression */
    if (current.type == TOKEN_NUMBER ||
        current.type == TOKEN_STRING ||
        current.type == TOKEN_TRUE ||
        current.type == TOKEN_FALSE ||
        current.type == TOKEN_LEFT_PAREN) {
        return parse_expression();
    }

    shriji_error_at(
        current,
        E_PARSE_02,
        "statement",
        "invalid statement",
        "use mavi / kaam / wapas / agar / jabtak / { } / bolo or expression"
    );

    return NULL;
}

/*──────────────────────────────────────────────
 | BLOCK { ... } BLOCK ✅
 *──────────────────────────────────────────────*/
static ASTNode *parse_block(void)
{
    if (!expect(TOKEN_LEFT_BRACE, E_PARSE_01, "{", "missing {", "{ stmt }"))
        return NULL;

    ASTNode **stmts = NULL;
    int count = 0;

    while (current.type != TOKEN_RIGHT_BRACE &&
           current.type != TOKEN_EOF) {

        skip_separators();

        if (current.type == TOKEN_RIGHT_BRACE)
            break;

        ASTNode *s = parse_statement();
        if (!s) return NULL;

        stmts = realloc(stmts, sizeof(ASTNode*) * (count + 1));
        stmts[count++] = s;

        skip_separators();
    }

    if (!expect(TOKEN_RIGHT_BRACE, E_PARSE_02, "}", "missing }", "{ stmt }"))
        return NULL;

    return new_block_node(stmts, count);
}

/*──────────────────────────────────────────────
 | IF / ELSE BLOCK ✅
 *──────────────────────────────────────────────*/
static ASTNode *parse_if(void)
{
    advance(); /* consume 'agar' */

    ASTNode *cond = parse_comparison();
    if (!cond) return NULL;

    skip_separators();

    ASTNode *then_block = parse_block();
    if (!then_block) return NULL;

    skip_separators();

    ASTNode *node = new_if_node(cond, then_block);

    if (current.type == TOKEN_WARNA) {
        advance(); /* consume 'warna' */
        skip_separators();

        node->else_block = parse_block();
        if (!node->else_block) return NULL;

        skip_separators();
    }

    return node;
}

/*──────────────────────────────────────────────
 | WHILE / JABTAK BLOCK ✅
 *──────────────────────────────────────────────*/
static ASTNode *parse_while(void)
{
    advance(); /* consume 'jabtak' */

    ASTNode *cond = parse_comparison();
    if (!cond) return NULL;

    skip_separators();

    ASTNode *body = parse_block();
    if (!body) return NULL;

    return new_while_node(cond, body);
}


/*──────────────────────────────────────────────
 | RETURN / WAPAS BLOCK ✅
 *──────────────────────────────────────────────*/

static ASTNode *parse_return(void)
{
    advance(); /* consume 'wapas' */

    /* allow: wapas alone */
    if (current.type == TOKEN_NEWLINE ||
        current.type == TOKEN_RIGHT_BRACE ||
        current.type == TOKEN_EOF) {

        skip_separators();
        return new_return_node(NULL);
    }

    /* return expression */
    ASTNode *val = parse_expression();
    if (!val) return NULL;

    skip_separators();
    return new_return_node(val);
}


/*──────────────────────────────────────────────
 | FUNCTION / KAAM BLOCK ✅
 | Syntax:
 |   kaam add(a, b) { ... }
 *──────────────────────────────────────────────*/
static ASTNode *parse_function(void)
{
    advance(); /* consume 'kaam' */
    skip_separators();

    if (current.type != TOKEN_IDENTIFIER) {
        shriji_error_at(
            current,
            E_PARSE_02,
            "kaam",
            "expected function name",
            "kaam add(a, b) { ... }"
        );
        return NULL;
    }

    char fname[128];
    strncpy(fname, current.start, current.length);
    fname[current.length] = 0;
    advance(); /* consume function name */

    skip_separators();

    if (!expect(TOKEN_LEFT_PAREN, E_PARSE_02, "(", "missing (", "kaam add(a, b) { ... }"))
        return NULL;

    ASTNode **params = NULL;
    int param_count = 0;

    skip_separators();

    if (current.type != TOKEN_RIGHT_PAREN) {
        while (1) {

            if (current.type != TOKEN_IDENTIFIER) {
                shriji_error_at(
                    current,
                    E_PARSE_02,
                    "params",
                    "expected parameter name",
                    "kaam add(a, b) { ... }"
                );
                return NULL;
            }

            char p[128];
            strncpy(p, current.start, current.length);
            p[current.length] = 0;
            advance();

            params = realloc(params, sizeof(ASTNode*) * (param_count + 1));
            params[param_count++] = new_identifier_node(p);

            skip_separators();

            if (current.type == TOKEN_COMMA) {
                advance();
                skip_separators();
            }

            if (current.type == TOKEN_RIGHT_PAREN)
                break;
        }
    }

    if (!expect(TOKEN_RIGHT_PAREN, E_PARSE_02, ")", "missing )", "kaam add(a, b) { ... }"))
        return NULL;

    skip_separators();

    ASTNode *body = parse_block();
    if (!body) return NULL;

    skip_separators();

    return new_function_node(fname, params, param_count, body);
}

/*──────────────────────────────────────────────
 | IDENTIFIER / UPDATE / CALL BLOCK ✅
 | Supports:
 |   x = expr
 |   x
 |   add(10, 20)
 *──────────────────────────────────────────────*/
static ASTNode *parse_update_or_identifier(void)
{
    if (current.type != TOKEN_IDENTIFIER)
        return NULL;

    char name[128];
    strncpy(name, current.start, current.length);
    name[current.length] = 0;
    advance(); /* consume identifier */

    skip_separators();

    /* CALL: name(...) */
    if (current.type == TOKEN_LEFT_PAREN) {

        advance(); /* consume '(' */
        skip_separators();

        ASTNode **args = NULL;
        int arg_count = 0;

        if (current.type != TOKEN_RIGHT_PAREN) {

            while (1) {

                ASTNode *arg = parse_comparison();
                if (!arg) return NULL;

                args = realloc(args, sizeof(ASTNode*) * (arg_count + 1));
                args[arg_count++] = arg;

                skip_separators();

                if (current.type == TOKEN_RIGHT_PAREN)
                    break;

                /* must be comma */
                if (!expect(TOKEN_COMMA, E_PARSE_02, ",", "expected ','", "example: add(10, 20)"))
                    return NULL;

                skip_separators();
            }
        }

        if (!expect(TOKEN_RIGHT_PAREN, E_PARSE_02, ")", "missing )", "example: add(10, 20)"))
            return NULL;

        skip_separators();
        return new_call_node(name, args, arg_count);
    }

    /* UPDATE: x = expr */
    if (current.type == TOKEN_EQUAL) {

        advance(); /* consume '=' */

        ASTNode *val = parse_comparison();
        if (!val) return NULL;

        skip_separators();
        return new_update_node(name, val);
    }

    /* identifier expression */
    return new_identifier_node(name);
}

/*──────────────────────────────────────────────
 | ASSIGNMENT (MAVI) BLOCK ✅
 *──────────────────────────────────────────────*/
static ASTNode *parse_assignment(void)
{
    advance(); /* consume 'mavi' */
    skip_separators();

    if (current.type != TOKEN_IDENTIFIER) {
        shriji_error_at(
            current,
            E_ASSIGN_01,
            "mavi",
            "expected variable name",
            "mavi x = 10"
        );
        return NULL;
    }

    char name[128];
    strncpy(name, current.start, current.length);
    name[current.length] = 0;
    advance();

    skip_separators();

    if (!expect(TOKEN_EQUAL, E_ASSIGN_01, "=", "missing =", "mavi x = 10"))
        return NULL;

    ASTNode *val = parse_comparison();
    if (!val) return NULL;

    skip_separators();
    return new_assignment_node(name, val);
}

/*──────────────────────────────────────────────
 | EXPRESSIONS BLOCK ✅
 | precedence:
 |   primary -> unary -> term -> expression -> comparison
 *──────────────────────────────────────────────*/
static ASTNode *parse_comparison(void)
{
    ASTNode *n = parse_expression();

    while (current.type == TOKEN_GT ||
           current.type == TOKEN_LT ||
           current.type == TOKEN_EQEQ ||
           current.type == TOKEN_NEQ) {

        char op =
            (current.type == TOKEN_GT)   ? '>' :
            (current.type == TOKEN_LT)   ? '<' :
            (current.type == TOKEN_EQEQ) ? '=' : '!';

        advance();
        n = new_binary_node(op, n, parse_expression());
    }

    return n;
}

static ASTNode *parse_expression(void)
{
    ASTNode *n = parse_term();

    while (current.type == TOKEN_PLUS || current.type == TOKEN_MINUS) {
        char op = (current.type == TOKEN_PLUS) ? '+' : '-';
        advance();
        n = new_binary_node(op, n, parse_term());
    }

    return n;
}

static ASTNode *parse_term(void)
{
    ASTNode *n = parse_unary();

    while (current.type == TOKEN_STAR ||
           current.type == TOKEN_SLASH ||
           current.type == TOKEN_MOD) {

        char op =
            (current.type == TOKEN_STAR)  ? '*' :
            (current.type == TOKEN_SLASH) ? '/' : '%';

        advance();
        n = new_binary_node(op, n, parse_unary());
    }

    return n;
}

static ASTNode *parse_unary(void)
{
    if (current.type == TOKEN_NAHI) {
        advance();
        return new_not_node(parse_unary());
    }

    return parse_primary();
}

/*──────────────────────────────────────────────
 | PRIMARY BLOCK ✅
 *──────────────────────────────────────────────*/
static ASTNode *parse_primary(void)
{
    if (current.type == TOKEN_LEFT_BRACE) {
        shriji_error_at(
            current,
            E_PARSE_02,
            "expr",
            "block not allowed here",
            "use { } only after agar/jabtak"
        );
        return NULL;
    }

    if (current.type == TOKEN_NUMBER) {
        int v = atoi(current.start);
        advance();
        return new_number_node(v);
    }

    if (current.type == TOKEN_STRING) {
        char s[256];
        int len = current.length;

        /* remove quotes */
        const char *p = current.start;
        if (len >= 2 && p[0] == '"' && p[len - 1] == '"') {
            p++;
            len -= 2;
        }

        if (len >= (int)sizeof(s)) len = (int)sizeof(s) - 1;
        strncpy(s, p, len);
        s[len] = 0;

        advance();
        return new_string_node(s);
    }

    if (current.type == TOKEN_TRUE) {
        advance();
        return new_number_node(1);
    }

    if (current.type == TOKEN_FALSE) {
        advance();
        return new_number_node(0);
    }


if (current.type == TOKEN_IDENTIFIER) {

        char name[128];
        strncpy(name, current.start, current.length);
        name[current.length] = 0;
        advance(); /* consume identifier */

        /* ✅ do NOT skip newlines here
           expression parsing must control separators */
        if (current.type == TOKEN_LEFT_PAREN) {

            advance(); /* consume '(' */
            skip_separators();

            ASTNode **args = NULL;
            int arg_count = 0;

            if (current.type != TOKEN_RIGHT_PAREN) {
                while (1) {

                    ASTNode *arg = parse_expression(); /* ✅ */
                    if (!arg) return NULL;

                    args = realloc(args, sizeof(ASTNode*) * (arg_count + 1));
                    args[arg_count++] = arg;

                    skip_separators();

                    if (current.type == TOKEN_RIGHT_PAREN)
                        break;

                    if (!expect(TOKEN_COMMA, E_PARSE_02, ",", "expected ','",
                                "example: add(10, 20)"))
                        return NULL;

                 }
            }

            if (!expect(TOKEN_RIGHT_PAREN, E_PARSE_02, ")", "missing )",
                        "example: add(10, 20)"))
                return NULL;

            skip_separators();
            return new_call_node(name, args, arg_count);
        }

        /* normal identifier */
        return new_identifier_node(name);
    }

    if (current.type == TOKEN_LEFT_PAREN) {
        advance();
        ASTNode *n = parse_comparison();
        if (!n) return NULL;
        expect(TOKEN_RIGHT_PAREN, E_PARSE_02, ")", "missing )", "(expr)");
        return n;
    }

    shriji_error_at(current, E_PARSE_02, "expr", "bad token", "check syntax");
    return NULL;
}
